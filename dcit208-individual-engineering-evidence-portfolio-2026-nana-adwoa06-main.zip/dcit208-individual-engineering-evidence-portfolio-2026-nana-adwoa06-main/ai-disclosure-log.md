# AI Disclosure Log

Use one entry per assignment. Write "No AI used" if you did not use AI.

| Assignment | Date | Tool | Prompt summary | Output used | Output rejected | Human verification steps |
|---|---|---|---|---|---|---|
| IA1 |  |  |  |  |  |  |
| IA2 |  |  |  |  |  |  |
| IA3 |  |  |  |  |  |  |
| IA4 |  |  |  |  |  |  |
| IA5 |  |  |  |  |  |  |
| IA6 |  |  |  |  |  |  |
| IA7 |  |  |  |  |  |  |
| IA8 |  |  |  |  |  |  |
| IA9 |  |  |  |  |  |  |
