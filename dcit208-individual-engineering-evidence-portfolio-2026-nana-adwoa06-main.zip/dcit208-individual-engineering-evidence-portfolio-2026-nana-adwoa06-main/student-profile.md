# Student Profile

- Full name:
- Student ID:
- Email:
- GitHub username:
- Team name:
- Project title:
- Team repository URL:
- Individual portfolio repository URL:

## Personal learning goal

Write 100-150 words explaining what you want to become able to explain confidently by the end of DCIT208.
