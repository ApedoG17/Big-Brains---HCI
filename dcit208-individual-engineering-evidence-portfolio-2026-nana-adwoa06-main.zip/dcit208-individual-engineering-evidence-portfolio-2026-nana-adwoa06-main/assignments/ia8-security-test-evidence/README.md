# Security Abuse-Case and Test Evidence Sheet

Place your final Sakai PDF and supporting evidence for this assignment in this folder.

Required minimum contents:

- Final PDF submitted on Sakai.
- Any required video link, screenshots, diagrams, notes, or evidence pointers.
- AI disclosure note or reference to `../../ai-disclosure-log.md`.
- Link to the related team repository evidence where project-specific.

Suggested file naming:

`IA8_SECURITY_TEST_EVIDENCE_StudentID_FullName.pdf`
