[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/1-l9xPxY)
[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-2e0aaae1b6195c2367325f4f02e2d04e9abb55f0b24a779b69b11b9e10269abc.svg)](https://classroom.github.com/online_ide?assignment_repo_id=24183864&assignment_repo_type=AssignmentRepo)
# DCIT208 Individual Engineering Evidence Portfolio 2026

This private repository is your personal evidence portfolio for DCIT208 individual anti-AI assignments.

Use this repository to store your final PDFs, supporting notes, video links, AI disclosure extracts, and evidence pointers. Sakai remains the official submission channel. This repository is additional evidence that the work belongs to you and can be traced to your GitHub account.

## Rules

1. Do not commit client secrets, passwords, API keys, tokens, private records, or identifiable personal data.
2. Do not fabricate client interviews, PRs, tests, commits, or videos.
3. Do not paste raw confidential client information into AI tools.
4. Every assignment folder must include your final PDF and any required links or supporting evidence.
5. Update `student-profile.md` before the first assignment.
6. Update `ai-disclosure-log.md` for every assignment, even if no AI was used.

## Folder structure

- `assignments/ia1-request-flow/`
- `assignments/ia2-client-discovery/`
- `assignments/ia3-traceability-card/`
- `assignments/ia4-backlog-defense/`
- `assignments/ia5-adr-memo/`
- `assignments/ia6-pr-review-autopsy/`
- `assignments/ia7-api-db-memo/`
- `assignments/ia8-security-test-evidence/`
- `assignments/ia9-interview-defense/`
- `videos/links.md`
- `ai/`
