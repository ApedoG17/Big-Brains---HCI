# DCIT208 Individual Engineering Evidence Portfolio Checklist

This repository is the student's private semester-long evidence portfolio for DCIT208 Software Engineering.

Sakai remains the official submission platform. This repository stores supporting evidence for individual accountability, AI disclosure, reflection, and interview readiness.

## Weekly evidence folders

- IA1: `ia1-request-flow/`
- IA2: `ia2-client-discovery/`
- IA3: `ia3-traceability-card/`
- IA4: `ia4-backlog-defense/`
- IA5: `ia5-architecture-decision-record/`
- IA6: `ia6-pr-review-autopsy/`
- IA7: `ia7-api-database-decision/`
- IA8: `ia8-security-test-evidence/`
- IA9: `ia9-interview-defense/`

## Every weekly folder should contain

1. The final PDF submitted on Sakai.
2. Any handwritten scan, diagram, screenshot, note, or reflection used as evidence.
3. A `video-link.txt` file where a video is required.
4. A short README or reflection where requested.
5. AI disclosure evidence.

## AI disclosure rule

Every student must disclose whether AI was used or not used.

Required statement:

"I used / did not use AI assistance. If used, the tool, purpose, prompt summary, output accepted/rejected and verification steps are documented."

## Important

A polished submission without personal understanding is not acceptable. Students must be able to explain and defend all work submitted in Sakai, this portfolio, and the team project repository.
