# Backend

Spring Boot + PostgreSQL backend for the Big-Brains HCI project.

## Stack
- Java 17
- Spring Boot 3.3.4 (Web, Data JPA, Validation)
- PostgreSQL

## Local setup

1. Install a local PostgreSQL server (or use a hosted one), and create a database:
   ```sql
   CREATE DATABASE bigbrains;
   ```

2. Set environment variables (or leave the defaults in `application.yml` for local dev):
   - `DB_URL` (default: `jdbc:postgresql://localhost:5432/bigbrains`)
   - `DB_USERNAME` (default: `postgres`)
   - `DB_PASSWORD` (default: `postgres`)
   - `PORT` (default: `8080`)

3. Run the app — easiest is via your IDE (IntelliJ/VS Code/Eclipse): open the `backend` folder as a Maven project and run `BackendApplication.java`.
   Or, if Maven is installed locally:
   ```bash
   mvn spring-boot:run
   ```

4. Check it's alive:
   ```
   GET http://localhost:8080/api/health
   ```

## Current endpoints

Placeholder `Item` CRUD — rename/replace with the real domain model once decided:

| Method | Path              | Description       |
|--------|-------------------|--------------------|
| GET    | /api/items        | List all items     |
| GET    | /api/items/{id}   | Get one item       |
| POST   | /api/items        | Create an item     |
| PUT    | /api/items/{id}   | Update an item     |
| DELETE | /api/items/{id}   | Delete an item     |
| GET    | /api/health       | Health check       |

## Structure

```
src/main/java/com/bigbrains/backend/
  controller/   REST endpoints
  service/      business logic
  repository/   Spring Data JPA repositories
  model/        JPA entities
  config/       app configuration (CORS, security, etc.)
```
